#include<stdio.h>
int main()
{
    double a=22.123456789123456;
    printf("%0.15lf",a);
    return 0;
}