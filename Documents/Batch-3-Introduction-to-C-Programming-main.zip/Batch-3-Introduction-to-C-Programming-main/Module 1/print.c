#include<stdio.h>
int main()
{
    printf("Hello World\t\t\tNew Tab e Jao");
    return 0;
}

// \n - new line 
// \t - tab            
// Hello World
// Now I am a programmer
