#include<stdio.h>
int main()
{
    int a,b;
    scanf("%d %db",&a,&b);
    printf("%da %db",a,b);
    return 0;
}